python -m foodvision_guard.train --config configs/fruit_bruise.yaml
