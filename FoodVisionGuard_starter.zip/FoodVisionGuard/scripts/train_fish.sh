python -m foodvision_guard.train --config configs/fish_freshness.yaml
